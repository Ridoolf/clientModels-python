from setuptools import setup

setup(
    
    name = 'package_client',
    version = '1.8',
    author = 'Lucas Ridolfi',
    author_email = 'lucasg.ridolfi@gmail.com',
    
    packages = ['package_client']
    
)
